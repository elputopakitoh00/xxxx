## extentreports-testng-adapter-example

View `src/test/` for examples.

### Bugs and Feature requests

You can register bugs and feature requests in the [Github Issue Tracker](https://github.com/extent-framework/extentreports-testng-adapter/issues).

### License

MIT
